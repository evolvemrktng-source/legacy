#!/usr/bin/env python3
"""One-time static-site generator for Legacy Builds Group.
Writes plain HTML files into the repo -- no build step at runtime."""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ---------------------------------------------------------------------------
# Icons
# ---------------------------------------------------------------------------
ICON_LOGO_MARK = '<svg viewBox="0 0 48 48" width="32" height="32"><rect width="48" height="48" rx="9" fill="currentColor" opacity="0.14"/><path d="M24 9 L38 20 V38 H28 V27 H20 V38 H10 V20 Z" fill="currentColor"/></svg>'

ICON_PHONE = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M22 16.9v3a2 2 0 01-2.2 2 19.8 19.8 0 01-8.6-3.1 19.5 19.5 0 01-6-6 19.8 19.8 0 01-3.1-8.7A2 2 0 014.1 2h3a2 2 0 012 1.7c.1 1 .3 2 .7 3a2 2 0 01-.5 2.1L8 10a16 16 0 006 6l1.2-1.3a2 2 0 012.1-.5c1 .4 2 .6 3 .7a2 2 0 011.7 2z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>'
ICON_MAIL = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="14" rx="2" stroke="currentColor" stroke-width="1.6"/><path d="M3 7l9 6 9-6" stroke="currentColor" stroke-width="1.6"/></svg>'
ICON_PIN = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 21s7-6.6 7-11.5A7 7 0 105 9.5C5 14.4 12 21 12 21z" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="9.5" r="2.3" stroke="currentColor" stroke-width="1.6"/></svg>'
ICON_CLOCK = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.6"/><path d="M12 7v5l3 3" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>'

ICON_FB = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M14 9h3V5.5h-3c-2.2 0-4 1.8-4 4V12H7v3.5h3V22h3.5v-6.5H16l.7-3.5h-3.2V9.6c0-.4.3-.6.5-.6z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/></svg>'
ICON_IG = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="5" stroke="currentColor" stroke-width="1.4"/><circle cx="12" cy="12" r="4" stroke="currentColor" stroke-width="1.4"/><circle cx="17.3" cy="6.7" r="1" fill="currentColor"/></svg>'
ICON_LI = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="3" stroke="currentColor" stroke-width="1.4"/><path d="M7.5 10.2v6.3M7.5 7.3v.1" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M11.3 16.5v-6.3M11.3 13v-.3a2.5 2.5 0 015 0v3.8" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>'

ICON_DESIGN = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M4 20l4.5-1.1L20 7.4a1.5 1.5 0 000-2.1l-1.3-1.3a1.5 1.5 0 00-2.1 0L5.1 15.5 4 20z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>'
ICON_ENGINEER = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.6"/><path d="M19.4 13a7.6 7.6 0 000-2l2-1.6-2-3.4-2.4 1a7.7 7.7 0 00-1.7-1L14.9 3h-3.8l-.4 2.6a7.7 7.7 0 00-1.7 1l-2.4-1-2 3.4L6.6 11a7.6 7.6 0 000 2l-2 1.6 2 3.4 2.4-1a7.7 7.7 0 001.7 1l.4 2.6h3.8l.4-2.6a7.7 7.7 0 001.7-1l2.4 1 2-3.4-2-1.6z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>'
ICON_BUILD = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M3 11l9-7 9 7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M5 10v10h14V10" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M10 20v-6h4v6" stroke="currentColor" stroke-width="1.6"/></svg>'

ICON_TEAM = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none"><circle cx="9" cy="8" r="3.2" stroke="currentColor" stroke-width="1.6"/><path d="M3.5 20a5.5 5.5 0 0111 0" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><circle cx="17" cy="9" r="2.4" stroke="currentColor" stroke-width="1.6"/><path d="M14.8 20a4.6 4.6 0 018.2-2.8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>'
ICON_LOCATION = ICON_PIN
ICON_MESSAGE = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M4 4h16v12H7l-3 3V4z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>'
ICON_CLOCK2 = ICON_CLOCK
ICON_MAP2 = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M9 4l-6 2v14l6-2 6 2 6-2V4l-6 2-6-2z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M9 4v14M15 6v14" stroke="currentColor" stroke-width="1.6"/></svg>'
ICON_VALUE = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 3l2.5 5.5L20 9l-4 4 1 6-5-3-5 3 1-6-4-4 5.5-.5z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>'

STAR = '<svg width="18" height="18" viewBox="0 0 24 24"><path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z" fill="currentColor"/></svg>'

FAVICON = 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect width=%22100%22 height=%22100%22 rx=%2220%22 fill=%22%23071522%22/><path d=%22M50 20 L80 45 L80 78 L58 78 L58 58 L42 58 L42 78 L20 78 L20 45 Z%22 fill=%22%23f5f3ef%22/></svg>'

NAV_ITEMS = [
    ("home", "/", "Home"),
    ("about", "/about.html", "About"),
    ("services", "/services.html", "Services"),
    ("projects", "/projects.html", "Projects"),
    ("process", "/#process", "Process"),
    ("insights", "/insights.html", "Insights"),
    ("contact", "/contact.html", "Contact"),
]


def nav_links(active, mobile=False):
    out = []
    for key, href, label in NAV_ITEMS:
        cls = ' class="active"' if key == active and not mobile else ""
        out.append(f'<a href="{href}"{cls}>{label}</a>')
    return "\n      ".join(out)


def header_html(active, header_extra_class=""):
    cls = "site-header" + (f" {header_extra_class}" if header_extra_class else "")
    return f"""<header class="{cls}" id="site-header">
  <div class="container header-inner">
    <a href="/" class="logo">
      <span class="logo-mark" aria-hidden="true">{ICON_LOGO_MARK}</span>
      <span class="logo-text">LEGACY BUILDS<em>GROUP</em></span>
    </a>
    <nav class="main-nav" id="main-nav">
      {nav_links(active)}
    </nav>
    <a href="/contact.html" class="btn btn-gold btn-sm header-cta">Start Your Project</a>
    <button class="nav-toggle" id="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>
  </div>
</header>

<div class="mobile-panel" id="mobile-panel">
  <nav>
    {nav_links(active, mobile=True)}
  </nav>
  <div class="mobile-panel-footer">
    <span>(313) 555-LEGACY</span>
    <span>info@legacybuildsgroup.com</span>
    <div class="mobile-panel-social">
      <a href="#" aria-label="Facebook">{ICON_FB}</a>
      <a href="#" aria-label="Instagram">{ICON_IG}</a>
      <a href="#" aria-label="LinkedIn">{ICON_LI}</a>
    </div>
    <a href="/contact.html" class="btn btn-gold btn-sm">Start Your Project</a>
  </div>
</div>"""


def footer_html():
    return f"""<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <a href="/" class="logo">
          <span class="logo-mark" aria-hidden="true">{ICON_LOGO_MARK}</span>
          <span class="logo-text">LEGACY BUILDS<em>GROUP</em></span>
        </a>
        <p class="footer-tagline">Design. Engineer. Build.</p>
      </div>
      <div class="footer-col">
        <h5>Company</h5>
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/about.html">About</a></li>
          <li><a href="/services.html">Services</a></li>
          <li><a href="/projects.html">Projects</a></li>
          <li><a href="/#process">Process</a></li>
          <li><a href="/insights.html">Insights</a></li>
          <li><a href="/contact.html">Contact</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h5>Services</h5>
        <ul>
          <li><a href="/services/architecture.html">Architecture</a></li>
          <li><a href="/services/engineering.html">Engineering</a></li>
          <li><a href="/services/mep-systems.html">MEP Systems</a></li>
          <li><a href="/services/construction.html">Construction</a></li>
          <li><a href="/services.html">Project Management</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h5>Contact</h5>
        <ul>
          <li>(313) 555-LEGACY</li>
          <li>info@legacybuildsgroup.com</li>
          <li>Metro Detroit, Michigan</li>
        </ul>
        <div class="footer-social">
          <a href="#" aria-label="Facebook">{ICON_FB}</a>
          <a href="#" aria-label="Instagram">{ICON_IG}</a>
          <a href="#" aria-label="LinkedIn">{ICON_LI}</a>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <p>&copy; <span class="js-year"></span> Legacy Builds Group. All rights reserved.</p>
      <div class="footer-legal">
        <a href="/privacy.html">Privacy Policy</a>
        <a href="/terms.html">Terms</a>
        <a href="/accessibility.html">Accessibility</a>
      </div>
    </div>
  </div>
</footer>"""


def page(title, description, canonical, active, body, extra_head="", header_extra_class=""):
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<meta name="description" content="{description}">
<link rel="canonical" href="https://www.legacybuildsgroup.com{canonical}">
<link rel="icon" href="{FAVICON}">
<link rel="stylesheet" href="/css/styles.css">
{extra_head}</head>
<body>
{header_html(active, header_extra_class)}

{body}

{footer_html()}
<script src="/js/main.js"></script>
</body>
</html>
"""


def write(path, content):
    full = os.path.join(ROOT, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w") as f:
        f.write(content)
    print("wrote", path)
