import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from generate_site import *

# ===========================================================================
# HOME  (index.html)  — Section 32 sequence
# ===========================================================================

home_schema = """<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "GeneralContractor",
  "name": "Legacy Builds Group",
  "description": "Design-build contractor providing architecture, engineering, MEP coordination, permitting, and construction services throughout Metro Detroit.",
  "areaServed": "Metro Detroit, MI",
  "telephone": "+1-313-555-3422",
  "email": "info@legacybuildsgroup.com",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Metro Detroit",
    "addressRegion": "MI",
    "addressCountry": "US"
  }
}
</script>
<!-- Schema fields above are placeholders per the Website Development Guide, Section 28.
     Verify and replace address, phone, and license details before launch. -->
"""

home_body = f"""<section class="hero" id="home">
  <div class="hero-media" aria-hidden="true"></div>
  <div class="hero-overlay"></div>
  <div class="container hero-content reveal">
    <span class="eyebrow">Metro Detroit Design-Build Firm</span>
    <h1>From Vision<br>to Reality.</h1>
    <p class="hero-sub">Design. Engineer. Build.</p>
    <p class="hero-body">Legacy Builds Group provides architecture, engineering, MEP coordination, permitting, and construction under one roof. From the earliest concept to final occupancy, one accountable team manages every stage of the project.</p>
    <div class="hero-actions">
      <a href="/contact.html" class="btn btn-gold">Start Your Project <span aria-hidden="true">&rarr;</span></a>
      <a href="/projects.html" class="btn btn-outline-white">View Our Work</a>
    </div>
  </div>
</section>

<div class="value-bar">
  <div class="container value-grid">
    <div class="value-col">
      <span class="value-title">Full Scope</span>
      <span class="value-sub">One Team</span>
    </div>
    <div class="value-col">
      <span class="value-title">Metro Detroit</span>
      <span class="value-sub">Local Expertise</span>
    </div>
    <div class="value-col">
      <span class="value-title">Built to Last</span>
      <span class="value-sub">Quality First</span>
    </div>
  </div>
</div>

<section class="about-body" id="about-intro">
  <div class="container about-grid">
    <div class="media-block about-media reveal" aria-hidden="true"></div>
    <div class="about-copy reveal">
      <span class="eyebrow">About Legacy Builds</span>
      <h2>Built Different. Built Better.</h2>
      <p>Legacy Builds Group is a full-service design-build company serving residential, commercial, and industrial clients throughout Metro Detroit. We manage architecture, engineering, MEP systems, permitting, construction, and project coordination through one integrated team.</p>
      <p>Our structure reduces handoffs, improves communication, and allows design decisions to be evaluated with real construction knowledge from the beginning.</p>
      <div class="service-labels">
        <span>Architecture</span><span>Engineering</span><span>MEP Systems</span><span>Construction</span>
      </div>
      <a href="/about.html" class="link-gold" style="margin-top:28px;">Learn More About Us <span aria-hidden="true">&rarr;</span></a>
    </div>
  </div>
</section>

<section class="section section-dark" id="services">
  <div class="container">
    <div class="section-head reveal">
      <span class="eyebrow">Our Services</span>
      <h2>Full-Scope. In-House. No Gaps.</h2>
    </div>
    <div class="services-grid">
      <article class="service-card reveal">
        <div class="service-media" aria-hidden="true"></div>
        <div class="service-body">
          <h3>Architecture</h3>
          <p>Concept development, architectural plans, elevations, visualization, space planning, and permit-ready documentation designed around your goals and the realities of construction.</p>
          <a href="/services/architecture.html" class="link-gold">Explore Architecture <span aria-hidden="true">&rarr;</span></a>
        </div>
      </article>
      <article class="service-card reveal">
        <div class="service-media" aria-hidden="true"></div>
        <div class="service-body">
          <h3>Engineering</h3>
          <p>Structural and technical engineering coordinated from the beginning to improve constructability, reduce conflicts, and support municipal approval.</p>
          <a href="/services/engineering.html" class="link-gold">Explore Engineering <span aria-hidden="true">&rarr;</span></a>
        </div>
      </article>
      <article class="service-card reveal">
        <div class="service-media" aria-hidden="true"></div>
        <div class="service-body">
          <h3>MEP Systems</h3>
          <p>Mechanical, electrical, and plumbing systems designed for performance, code compliance, energy efficiency, and coordination with the architectural vision.</p>
          <a href="/services/mep-systems.html" class="link-gold">Explore MEP Systems <span aria-hidden="true">&rarr;</span></a>
        </div>
      </article>
      <article class="service-card reveal">
        <div class="service-media" aria-hidden="true"></div>
        <div class="service-body">
          <h3>Construction</h3>
          <p>Hands-on project management, subcontractor coordination, scheduling, quality control, inspections, and closeout from foundation through final completion.</p>
          <a href="/services/construction.html" class="link-gold">Explore Construction <span aria-hidden="true">&rarr;</span></a>
        </div>
      </article>
    </div>
  </div>
</section>

<section class="section section-white" id="projects">
  <div class="container">
    <div class="section-head reveal">
      <span class="eyebrow">Featured Projects</span>
      <h2 class="dark-text">We Build What Matters.</h2>
    </div>
    <div class="projects-feature">
      <a href="/projects/custom-luxury-home.html" class="project-hero-media reveal" aria-label="View the Custom Luxury Homes project">
        <div class="project-hero-card">
          <span class="tag">Residential</span>
          <h3>Custom Luxury Homes</h3>
          <p>Complete residential delivery from vacant land and architectural concept through construction and move-in.</p>
          <span class="btn btn-outline-white btn-sm">View Project <span aria-hidden="true">&rarr;</span></span>
        </div>
      </a>
      <div class="projects-strip">
        <a href="/projects.html" class="project-thumb reveal" aria-label="View commercial projects">
          <div class="project-thumb-body">
            <span class="tag">Commercial</span>
            <h4>Office, Retail &amp; Hospitality</h4>
          </div>
        </a>
        <a href="/projects.html" class="project-thumb reveal" aria-label="View industrial projects">
          <div class="project-thumb-body">
            <span class="tag">Industrial</span>
            <h4>Facilities &amp; Warehouses</h4>
          </div>
        </a>
      </div>
    </div>
  </div>
</section>

<section class="section section-graybg" id="transformation">
  <div class="container">
    <div class="section-head center reveal">
      <span class="eyebrow">Transformation</span>
      <h2 class="dark-text">Show the Work. Prove the Value.</h2>
      <p class="section-sub-dark" style="max-width:640px;margin-left:auto;margin-right:auto;">Every successful project begins with a problem, a vision, or an existing condition. Before-and-after project stories show how planning, design, engineering, and construction come together.</p>
    </div>

    <div class="ba-slider reveal" id="ba-slider">
      <div class="ba-image ba-after" aria-hidden="true"><span class="ba-tag ba-tag-after">After</span></div>
      <div class="ba-image ba-before" id="ba-before" aria-hidden="true"><span class="ba-tag ba-tag-before">Before</span></div>
      <div class="ba-handle" id="ba-handle"><span class="ba-handle-grip">&#10094;&#10095;</span></div>
      <input type="range" min="0" max="100" value="50" class="ba-range" id="ba-range" aria-label="Before and after comparison slider">
    </div>
    <div class="ba-nav">
      <button class="ba-btn" id="ba-prev" aria-label="Previous project">&#10094;</button>
      <button class="ba-btn" id="ba-next" aria-label="Next project">&#10095;</button>
    </div>
    <p class="ba-meta">
      <span><strong>Project:</strong> Kitchen &amp; Great Room Renovation</span>
      <span><strong>Location:</strong> Birmingham, MI</span>
      <span><strong>Duration:</strong> 14 Weeks</span>
      <span><strong>Services:</strong> Architecture, MEP, Construction</span>
    </p>
  </div>
</section>

<section class="section section-dark" id="process">
  <div class="container">
    <div class="section-head reveal">
      <span class="eyebrow">How We Work</span>
      <h2>One accountable path from idea to occupancy.</h2>
    </div>
    <div class="process-grid">
      <div class="process-step reveal">
        <span class="process-num">01</span>
        <h3>Discover</h3>
        <p>Review goals, site, budget, schedule, existing conditions, and municipal requirements.</p>
      </div>
      <div class="process-step reveal">
        <span class="process-num">02</span>
        <h3>Design</h3>
        <p>Develop and coordinate architecture, engineering, and MEP systems.</p>
      </div>
      <div class="process-step reveal">
        <span class="process-num">03</span>
        <h3>Approve</h3>
        <p>Prepare permit drawings and coordinate municipal review.</p>
      </div>
      <div class="process-step reveal">
        <span class="process-num">04</span>
        <h3>Build</h3>
        <p>Manage construction, scheduling, quality, inspections, and closeout.</p>
      </div>
    </div>
    <div class="process-flow reveal">
      <span class="step">Consultation</span><span class="arrow">&rarr;</span>
      <span class="step">Site &amp; Feasibility Review</span><span class="arrow">&rarr;</span>
      <span class="step">Architectural Design</span><span class="arrow">&rarr;</span>
      <span class="step">Engineering &amp; MEP</span><span class="arrow">&rarr;</span>
      <span class="step">Permits &amp; Approvals</span><span class="arrow">&rarr;</span>
      <span class="step">Construction</span><span class="arrow">&rarr;</span>
      <span class="step">Final Walkthrough &amp; Occupancy</span>
    </div>
  </div>
</section>

<section class="section section-warm" id="why-us">
  <div class="container">
    <div class="section-head center reveal">
      <span class="eyebrow">Why Clients Choose Us</span>
      <h2 class="dark-text">Owners on the job. Experts at every stage.</h2>
    </div>
    <div class="why-grid">
      <div class="why-card reveal">
        <span class="why-icon">{ICON_TEAM}</span>
        <h4>Full Scope, One Team</h4>
        <p>Architecture, engineering, MEP, permitting, and construction are coordinated through one accountable company.</p>
      </div>
      <div class="why-card reveal">
        <span class="why-icon">{ICON_BUILD}</span>
        <h4>Owners on the Job</h4>
        <p>Leadership is directly involved in planning, site coordination, subcontractor management, and client communication.</p>
      </div>
      <div class="why-card reveal">
        <span class="why-icon">{ICON_LOCATION}</span>
        <h4>Metro Detroit Experience</h4>
        <p>Knowledge of local municipalities, permitting requirements, inspections, and regional construction practices.</p>
      </div>
      <div class="why-card reveal">
        <span class="why-icon">{ICON_MESSAGE}</span>
        <h4>Clear Communication</h4>
        <p>Clients receive direct updates, clear next steps, and transparent explanations.</p>
      </div>
      <div class="why-card reveal">
        <span class="why-icon">{ICON_MAP2}</span>
        <h4>Residential to Industrial</h4>
        <p>Experience across custom homes, additions, offices, retail, restaurants, warehouses, and industrial facilities.</p>
      </div>
      <div class="why-card reveal">
        <span class="why-icon">{ICON_VALUE}</span>
        <h4>Built for Long-Term Value</h4>
        <p>Projects are evaluated for quality, constructability, functionality, maintenance, and long-term performance.</p>
      </div>
    </div>
  </div>
</section>

<section class="section testimonial-section" id="testimonials">
  <div class="container">
    <div class="testimonial-inner">
      <span class="eyebrow eyebrow-light">What Our Clients Say</span>
      <div class="stars" aria-label="5 out of 5 stars">{STAR * 5}</div>
      <p class="quote">&ldquo;Legacy Builds Group handled everything from permits to occupancy. The quality and attention to detail exceeded our expectations.&rdquo;</p>
      <p class="quote-author">&mdash; Sample Client, Residential Project, Metro Detroit</p>
      <span class="status-pill" style="margin-top:18px;display:inline-block;border-color:rgba(245,243,239,0.25);color:rgba(245,243,239,0.55);">Sample review &mdash; pending client approval before launch</span>
      <div class="testimonial-dots">
        <button class="dot active" aria-label="Testimonial 1"></button>
        <button class="dot" aria-label="Testimonial 2"></button>
        <button class="dot" aria-label="Testimonial 3"></button>
      </div>
    </div>
  </div>
</section>

<section class="section section-white" id="insights-preview">
  <div class="container">
    <div class="section-head center reveal">
      <span class="eyebrow">Insights</span>
      <h2 class="dark-text">Resources for Your Project.</h2>
    </div>
    <div class="insights-grid">
      <article class="insight-card reveal">
        <div class="insight-media" aria-hidden="true"></div>
        <div class="insight-body">
          <span class="tag">Construction Planning</span>
          <h3>What Is a Design-Build Contractor?</h3>
          <p>A plain-language look at the design-build delivery model and how it differs from hiring separate firms.</p>
          <a href="/insights/what-is-a-design-build-contractor.html" class="link-gold">Read Article <span aria-hidden="true">&rarr;</span></a>
        </div>
      </article>
      <article class="insight-card disabled reveal">
        <div class="insight-media" aria-hidden="true"></div>
        <div class="insight-body">
          <span class="tag">Construction Planning</span>
          <h3>Design-Build vs. Design-Bid-Build</h3>
          <p>How the two most common project delivery methods compare on cost, schedule, and accountability.</p>
          <span class="status-pill">Coming Soon</span>
        </div>
      </article>
      <article class="insight-card disabled reveal">
        <div class="insight-media" aria-hidden="true"></div>
        <div class="insight-body">
          <span class="tag">Permitting</span>
          <h3>What to Expect During the Permitting Process</h3>
          <p>A walkthrough of municipal review, common delays, and how to keep a project moving.</p>
          <span class="status-pill">Coming Soon</span>
        </div>
      </article>
    </div>
    <p style="text-align:center;margin-top:40px;">
      <a href="/insights.html" class="link-gold">View All Insights <span aria-hidden="true">&rarr;</span></a>
    </p>
  </div>
</section>

<section class="section section-cta" id="contact">
  <div class="container cta-inner reveal">
    <span class="eyebrow eyebrow-light">Let&rsquo;s Build Together</span>
    <h2>Have a project in mind?</h2>
    <p>Tell us what you are planning. Our team will review the project details and contact you to discuss scope, site conditions, timing, budget expectations, and next steps.</p>
    <div class="cta-actions">
      <a href="/contact.html" class="btn btn-gold">Start Your Project</a>
      <a href="tel:+13135553422" class="btn btn-outline-white">Call Our Team</a>
    </div>
  </div>
</section>
"""

write("index.html", page(
    title="Legacy Builds Group | Design-Build Contractor in Metro Detroit",
    description="Legacy Builds Group provides architecture, engineering, MEP coordination, permitting, and construction services for residential, commercial, and industrial projects throughout Metro Detroit.",
    canonical="/",
    active="home",
    body=home_body,
    extra_head=home_schema,
))

# ===========================================================================
# FINAL CTA (shared block, reused on inner pages)
# ===========================================================================

def final_cta():
    return """<section class="section section-cta">
  <div class="container cta-inner reveal">
    <span class="eyebrow eyebrow-light">Let&rsquo;s Build Together</span>
    <h2>Have a project in mind?</h2>
    <p>Tell us what you are planning. Our team will review the project details and contact you to discuss scope, site conditions, timing, budget expectations, and next steps.</p>
    <div class="cta-actions">
      <a href="/contact.html" class="btn btn-gold">Start Your Project</a>
      <a href="tel:+13135553422" class="btn btn-outline-white">Call Our Team</a>
    </div>
  </div>
</section>"""


def breadcrumb(*crumbs):
    parts = []
    for i, (label, href) in enumerate(crumbs):
        if href:
            parts.append(f'<a href="{href}">{label}</a>')
        else:
            parts.append(f'<span>{label}</span>')
    return '<p class="breadcrumb">' + ' <span aria-hidden="true">/</span> '.join(parts) + '</p>'

# ===========================================================================
# ABOUT  (about.html) — Section 15
# ===========================================================================

about_body = f"""<section class="page-hero">
  <div class="container">
    {breadcrumb(("Home", "/"), ("About", None))}
    <h1>Built on Accountability.<br>Driven by the Work.</h1>
    <p class="page-hero-sub">A Metro Detroit design-build team managing architecture, engineering, MEP, and construction under one roof.</p>
  </div>
</section>

<section class="section section-warm">
  <div class="container-narrow">
    <div class="section-head reveal">
      <span class="eyebrow">Our Story</span>
      <h2 class="dark-text">A More Coordinated Way to Build</h2>
    </div>
    <p class="reveal" style="color:var(--gray-600);font-size:1.05rem;max-width:760px;">Legacy Builds Group was established to solve one of the construction industry&rsquo;s most common problems: fragmented responsibility. Too often, the architect, engineer, contractor, and subcontractors work independently, leaving the client to manage gaps between them. Our design-build model brings these disciplines together. The result is clearer communication, stronger coordination, fewer surprises, and a project team that remains accountable from the first conversation through final completion.</p>
  </div>
</section>

<section class="section section-white">
  <div class="container">
    <div class="mv-grid">
      <div class="mv-card reveal">
        <span class="eyebrow">Mission</span>
        <p>Deliver fully coordinated design-build solutions that meet high standards of quality, schedule, communication, and long-term performance.</p>
      </div>
      <div class="mv-card reveal">
        <span class="eyebrow">Vision</span>
        <p>Become Metro Detroit&rsquo;s most trusted design-build company for clients who need one capable team to take a project from concept to certificate of occupancy.</p>
      </div>
    </div>
  </div>
</section>

<section class="section section-dark">
  <div class="container">
    <div class="section-head center reveal">
      <span class="eyebrow">What We Stand For</span>
      <h2>Core Values</h2>
    </div>
    <div class="values-grid">
      <div class="value-chip reveal">Accountability</div>
      <div class="value-chip reveal">Quality</div>
      <div class="value-chip reveal">Transparency</div>
      <div class="value-chip reveal">Coordination</div>
      <div class="value-chip reveal">Ownership</div>
      <div class="value-chip reveal">Long-Term Value</div>
    </div>
  </div>
</section>

<section class="section section-white">
  <div class="container">
    <div class="section-head center reveal">
      <span class="eyebrow">Leadership</span>
      <h2 class="dark-text">Meet the Team</h2>
      <p class="section-sub-dark" style="max-width:600px;margin:14px auto 0;">Sample leadership profiles &mdash; replace with your partners&rsquo; names, portraits, and biographies before launch.</p>
    </div>
    <div class="partners-grid">
      <div class="partner-card reveal">
        <div class="partner-photo" aria-hidden="true"></div>
        <h4>Founding Partner</h4>
        <p class="partner-role">Design &amp; Client Relations</p>
        <p class="partner-bio">Leads early-stage planning and client communication, translating project goals into an actionable architectural and construction strategy.</p>
        <div class="partner-tags"><span>Architecture</span><span>Client Strategy</span></div>
        <a href="#" class="partner-linkedin">{ICON_LI} LinkedIn</a>
      </div>
      <div class="partner-card reveal">
        <div class="partner-photo" aria-hidden="true"></div>
        <h4>Director of Engineering</h4>
        <p class="partner-role">Structural &amp; MEP Coordination</p>
        <p class="partner-bio">Oversees structural and MEP coordination, ensuring engineering decisions support constructability and code compliance from day one.</p>
        <div class="partner-tags"><span>Engineering</span><span>MEP Systems</span></div>
        <a href="#" class="partner-linkedin">{ICON_LI} LinkedIn</a>
      </div>
      <div class="partner-card reveal">
        <div class="partner-photo" aria-hidden="true"></div>
        <h4>Director of Construction</h4>
        <p class="partner-role">Field Operations &amp; Quality Control</p>
        <p class="partner-bio">Manages subcontractor coordination, scheduling, inspections, and quality control from foundation through closeout.</p>
        <div class="partner-tags"><span>Construction</span><span>Scheduling</span></div>
        <a href="#" class="partner-linkedin">{ICON_LI} LinkedIn</a>
      </div>
    </div>
  </div>
</section>

{final_cta()}
"""

write("about.html", page(
    title="About Legacy Builds Group | Metro Detroit Design-Build Team",
    description="Legacy Builds Group is a Metro Detroit design-build company built on accountability, coordinating architecture, engineering, MEP, and construction under one roof.",
    canonical="/about.html",
    active="about",
    body=about_body,
))

# ===========================================================================
# SERVICES OVERVIEW  (services.html) — Section 16
# ===========================================================================

services_body = f"""<section class="page-hero">
  <div class="container">
    {breadcrumb(("Home", "/"), ("Services", None))}
    <h1>Everything the Project Needs.<br>One Team.</h1>
    <p class="page-hero-sub">Successful projects depend on more than construction alone. Legacy Builds Group coordinates the architectural, engineering, MEP, permitting, and field requirements through one integrated delivery model.</p>
  </div>
</section>

<section class="section-white">
  <div class="container">
    <div class="alt-row reveal">
      <div class="alt-media" aria-hidden="true"></div>
      <div class="alt-copy">
        <span class="eyebrow">01 &mdash; Architecture</span>
        <h2>Design That Can Be Built</h2>
        <p>Concept development, architectural plans, elevations, visualization, space planning, and permit-ready documentation designed around your goals and the realities of construction.</p>
        <ul class="checklist">
          <li>Concept design &amp; space planning</li>
          <li>3D visualization</li>
          <li>Permit-ready construction drawings</li>
        </ul>
        <a href="/services/architecture.html" class="link-gold">Explore Architecture <span aria-hidden="true">&rarr;</span></a>
      </div>
    </div>

    <div class="alt-row reverse reveal">
      <div class="alt-media" aria-hidden="true"></div>
      <div class="alt-copy">
        <span class="eyebrow">02 &mdash; Engineering</span>
        <h2>Engineering Integrated From Day One</h2>
        <p>Structural and technical engineering coordinated from the beginning to improve constructability, reduce conflicts, and support municipal approval.</p>
        <ul class="checklist">
          <li>Structural &amp; foundation design</li>
          <li>Load-path review</li>
          <li>Construction support &amp; municipal responses</li>
        </ul>
        <a href="/services/engineering.html" class="link-gold">Explore Engineering <span aria-hidden="true">&rarr;</span></a>
      </div>
    </div>

    <div class="alt-row reveal">
      <div class="alt-media" aria-hidden="true"></div>
      <div class="alt-copy">
        <span class="eyebrow">03 &mdash; MEP Systems</span>
        <h2>Building Systems That Work Together</h2>
        <p>Mechanical, electrical, and plumbing systems affect comfort, safety, energy use, code compliance, maintenance, and construction cost &mdash; coordinated with architecture and structure to reduce conflicts before construction.</p>
        <ul class="checklist">
          <li>HVAC &amp; energy-code coordination</li>
          <li>Lighting, power &amp; life-safety systems</li>
          <li>Plumbing &amp; fixture layouts</li>
        </ul>
        <a href="/services/mep-systems.html" class="link-gold">Explore MEP Systems <span aria-hidden="true">&rarr;</span></a>
      </div>
    </div>

    <div class="alt-row reverse reveal">
      <div class="alt-media" aria-hidden="true"></div>
      <div class="alt-copy">
        <span class="eyebrow">04 &mdash; Construction</span>
        <h2>From Plans to Finished Structure</h2>
        <p>The construction team manages execution, subcontractor coordination, scheduling, inspections, quality control, and client communication from preconstruction through certificate of occupancy.</p>
        <ul class="checklist">
          <li>Preconstruction &amp; estimating</li>
          <li>Site supervision &amp; safety coordination</li>
          <li>Quality control, punch list &amp; closeout</li>
        </ul>
        <a href="/services/construction.html" class="link-gold">Explore Construction <span aria-hidden="true">&rarr;</span></a>
      </div>
    </div>
  </div>
</section>

{final_cta()}
"""

write("services.html", page(
    title="Services | Legacy Builds Group",
    description="Architecture, engineering, MEP systems, and construction &mdash; coordinated through one integrated design-build team at Legacy Builds Group.",
    canonical="/services.html",
    active="services",
    body=services_body,
))

# ===========================================================================
# SERVICE DETAIL PAGE TEMPLATE
# ===========================================================================

def service_page(slug, eyebrow, title_html, intro, extra_body, canonical_desc):
    body = f"""<section class="page-hero">
  <div class="container">
    {breadcrumb(("Home", "/"), ("Services", "/services.html"), (eyebrow, None))}
    <h1>{title_html}</h1>
    <p class="page-hero-sub">{intro}</p>
  </div>
</section>
{extra_body}
{final_cta()}
"""
    write(f"services/{slug}.html", page(
        title=f"{eyebrow} Services | Legacy Builds Group",
        description=canonical_desc,
        canonical=f"/services/{slug}.html",
        active="services",
        body=body,
    ))


# --- Architecture ---
architecture_extra = """<section class="section section-white">
  <div class="container">
    <div class="section-head reveal">
      <span class="eyebrow">What&rsquo;s Included</span>
      <h2 class="dark-text">Architectural Capabilities</h2>
    </div>
    <div class="capability-grid">
      <div class="capability-item reveal"><span class="dot"></span>Site planning</div>
      <div class="capability-item reveal"><span class="dot"></span>Concept design</div>
      <div class="capability-item reveal"><span class="dot"></span>Floor plans</div>
      <div class="capability-item reveal"><span class="dot"></span>Exterior elevations</div>
      <div class="capability-item reveal"><span class="dot"></span>Space planning</div>
      <div class="capability-item reveal"><span class="dot"></span>Interior layouts</div>
      <div class="capability-item reveal"><span class="dot"></span>3D visualization</div>
      <div class="capability-item reveal"><span class="dot"></span>Construction drawings</div>
      <div class="capability-item reveal"><span class="dot"></span>Permit drawings</div>
      <div class="capability-item reveal"><span class="dot"></span>Existing-condition documentation</div>
      <div class="capability-item reveal"><span class="dot"></span>Design coordination</div>
      <div class="capability-item reveal"><span class="dot"></span>Municipal revisions</div>
    </div>

    <div class="section-head reveal" style="margin-top:64px;">
      <span class="eyebrow">Architecture Workflow</span>
      <h2 class="dark-text">How a Project Takes Shape</h2>
    </div>
    <div class="workflow reveal">
      <span class="step">Client Consultation</span><span class="arrow">&rarr;</span>
      <span class="step">Site Review</span><span class="arrow">&rarr;</span>
      <span class="step">Concept Development</span><span class="arrow">&rarr;</span>
      <span class="step">Design Refinement</span><span class="arrow">&rarr;</span>
      <span class="step">Engineering Coordination</span><span class="arrow">&rarr;</span>
      <span class="step">Permit Documents</span><span class="arrow">&rarr;</span>
      <span class="step">Municipal Submission</span><span class="arrow">&rarr;</span>
      <span class="step">Construction Support</span>
    </div>
  </div>
</section>"""

service_page(
    "architecture", "Architecture", "Architecture That Can Be Built",
    "Our architectural process balances design, functionality, site conditions, municipal requirements, budget, and constructability.",
    architecture_extra,
    "Legacy Builds Group's architecture services cover concept design, permit-ready drawings, and 3D visualization built around real construction knowledge."
)

# --- Engineering ---
engineering_extra = """<section class="section section-white">
  <div class="container">
    <div class="section-head reveal">
      <span class="eyebrow">What&rsquo;s Included</span>
      <h2 class="dark-text">Engineering Capabilities</h2>
    </div>
    <div class="capability-grid">
      <div class="capability-item reveal"><span class="dot"></span>Structural coordination</div>
      <div class="capability-item reveal"><span class="dot"></span>Foundation design</div>
      <div class="capability-item reveal"><span class="dot"></span>Framing coordination</div>
      <div class="capability-item reveal"><span class="dot"></span>Load-path review</div>
      <div class="capability-item reveal"><span class="dot"></span>Existing building analysis</div>
      <div class="capability-item reveal"><span class="dot"></span>Design revisions</div>
      <div class="capability-item reveal"><span class="dot"></span>Construction support</div>
      <div class="capability-item reveal"><span class="dot"></span>Municipal responses</div>
    </div>
    <div class="callout reveal">
      <strong>Professional Disclaimer</strong>
      Engineering services are performed by or coordinated with appropriately licensed professionals based on project jurisdiction and scope.
    </div>
  </div>
</section>"""

service_page(
    "engineering", "Engineering", "Engineering Integrated From Day One",
    "Engineering decisions should not be treated as an afterthought. Our coordinated workflow evaluates structural and technical requirements while the design is still being developed.",
    engineering_extra,
    "Structural and technical engineering coordinated from day one to improve constructability and support municipal approval on every Legacy Builds Group project."
)

# --- MEP Systems ---
mep_extra = """<section class="section section-white">
  <div class="container">
    <div class="section-head reveal">
      <span class="eyebrow">What&rsquo;s Included</span>
      <h2 class="dark-text">Mechanical, Electrical &amp; Plumbing</h2>
    </div>
    <div class="subgroup-grid">
      <div class="subgroup-card reveal">
        <h3>Mechanical</h3>
        <ul class="checklist">
          <li>HVAC layouts</li>
          <li>Equipment coordination</li>
          <li>Ventilation and exhaust</li>
          <li>Energy-code requirements</li>
          <li>Mechanical schedules</li>
        </ul>
      </div>
      <div class="subgroup-card reveal">
        <h3>Electrical</h3>
        <ul class="checklist">
          <li>Lighting layouts</li>
          <li>Power distribution</li>
          <li>Panel schedules</li>
          <li>Load calculations</li>
          <li>Service coordination</li>
          <li>Life-safety systems</li>
        </ul>
      </div>
      <div class="subgroup-card reveal">
        <h3>Plumbing</h3>
        <ul class="checklist">
          <li>Water distribution</li>
          <li>Sanitary systems</li>
          <li>Fixture layouts</li>
          <li>Equipment connections</li>
          <li>Riser diagrams</li>
          <li>Code coordination</li>
        </ul>
      </div>
    </div>
  </div>
</section>"""

service_page(
    "mep-systems", "MEP Systems", "Building Systems That Work Together",
    "Mechanical, electrical, and plumbing systems affect comfort, safety, energy use, code compliance, maintenance, and construction cost. We coordinate these systems with the architecture and structure to reduce conflicts before construction.",
    mep_extra,
    "Mechanical, electrical, and plumbing systems designed for performance, code compliance, and energy efficiency, coordinated with architecture from the start."
)

# --- Construction ---
construction_stages = [
    ("Preconstruction", "Finalize scope, budget, and schedule before ground is broken."),
    ("Estimating", "Detailed cost estimates aligned with the approved design."),
    ("Scheduling", "A construction schedule coordinated across every trade."),
    ("Procurement", "Materials and subcontractors secured on the project timeline."),
    ("Site Supervision", "Daily on-site oversight of progress and workmanship."),
    ("Subcontractor Coordination", "Trades sequenced to avoid conflicts and delays."),
    ("Safety Coordination", "Job-site safety standards enforced throughout construction."),
    ("Inspections", "Municipal inspections scheduled and coordinated at each stage."),
    ("Change Management", "Any scope changes documented and approved before proceeding."),
    ("Quality Control", "Workmanship checked against plans and specifications."),
    ("Punch List", "Final details identified and resolved before handover."),
    ("Closeout", "Final documentation, warranties, and certificate of occupancy."),
]
timeline_html = "\n".join(
    f"""      <div class="timeline-item reveal">
        <span class="timeline-dot">{i+1:02d}</span>
        <div class="timeline-body"><h4>{name}</h4><p>{desc}</p></div>
      </div>""" for i, (name, desc) in enumerate(construction_stages)
)
construction_extra = f"""<section class="section section-white">
  <div class="container">
    <div class="section-head reveal">
      <span class="eyebrow">What&rsquo;s Included</span>
      <h2 class="dark-text">Construction Capabilities</h2>
    </div>
    <div class="capability-grid">
      <div class="capability-item reveal"><span class="dot"></span>Preconstruction</div>
      <div class="capability-item reveal"><span class="dot"></span>Estimating</div>
      <div class="capability-item reveal"><span class="dot"></span>Scheduling</div>
      <div class="capability-item reveal"><span class="dot"></span>Procurement</div>
      <div class="capability-item reveal"><span class="dot"></span>Site supervision</div>
      <div class="capability-item reveal"><span class="dot"></span>Subcontractor coordination</div>
      <div class="capability-item reveal"><span class="dot"></span>Safety coordination</div>
      <div class="capability-item reveal"><span class="dot"></span>Inspections</div>
      <div class="capability-item reveal"><span class="dot"></span>Change management</div>
      <div class="capability-item reveal"><span class="dot"></span>Quality control</div>
      <div class="capability-item reveal"><span class="dot"></span>Punch list</div>
      <div class="capability-item reveal"><span class="dot"></span>Closeout</div>
    </div>

    <div class="section-head reveal" style="margin-top:64px;">
      <span class="eyebrow">From Preconstruction to Occupancy</span>
      <h2 class="dark-text">Construction Timeline</h2>
    </div>
    <div class="timeline">
{timeline_html}
    </div>
  </div>
</section>"""

service_page(
    "construction", "Construction", "From Plans to Finished Structure",
    "The construction team manages execution, subcontractor coordination, scheduling, inspections, quality control, and client communication.",
    construction_extra,
    "Hands-on construction management from foundation through final completion, with subcontractor coordination, scheduling, and quality control handled in-house."
)

# ===========================================================================
# PROJECTS  (projects.html) — Section 21
# ===========================================================================

FILTERS = ["All", "Residential", "Commercial", "Industrial", "Architecture", "Renovation", "New Construction", "In Progress", "Completed"]

# (title, city, category_tag, filter-tags, status, href or None)
PROJECT_CARDS = [
    ("Custom Luxury Home", "Bloomfield Hills, MI", "Residential", "residential architecture new-construction completed", "Completed", "/projects/custom-luxury-home.html"),
    ("Kitchen & Great Room Renovation", "Birmingham, MI", "Residential", "residential renovation completed", "Completed", None),
    ("Boutique Office Build-Out", "Royal Oak, MI", "Commercial", "commercial architecture completed", "Completed", None),
    ("Neighborhood Restaurant Fit-Out", "Ferndale, MI", "Commercial", "commercial renovation completed", "Completed", None),
    ("Distribution Warehouse Expansion", "Livonia, MI", "Industrial", "industrial new-construction in-progress", "In Progress", None),
    ("Whole-Home Addition", "Northville, MI", "Residential", "residential renovation in-progress", "In Progress", None),
    ("Retail Storefront Renovation", "Troy, MI", "Commercial", "commercial renovation completed", "Completed", None),
    ("Light-Industrial Facility", "Sterling Heights, MI", "Industrial", "industrial architecture new-construction in-progress", "In Progress", None),
]

def project_card(title, city, tag, filters, status, href):
    inner = f"""<div class="project-card-media" aria-hidden="true"><span class="status-pill">{status}</span></div>
        <div class="project-card-body">
          <span class="tag">{tag}</span>
          <h3>{title}</h3>
          <p class="meta">{city}</p>
        </div>"""
    if href:
        return f'<a href="{href}" class="project-card reveal" data-category="{filters}">{inner}</a>'
    return f'<div class="project-card reveal" data-category="{filters}" style="cursor:default;">{inner}</div>'

filter_buttons = "\n      ".join(
    f'<button class="filter-btn{" active" if f == "All" else ""}" data-filter="{f.lower().replace(" ", "-")}">{f}</button>'
    for f in FILTERS
)
project_cards_html = "\n      ".join(project_card(*c) for c in PROJECT_CARDS)

projects_body = f"""<section class="page-hero">
  <div class="container">
    {breadcrumb(("Home", "/"), ("Projects", None))}
    <h1>Our Projects</h1>
    <p class="page-hero-sub">A filterable look at residential, commercial, and industrial work across Metro Detroit &mdash; from architecture through final construction.</p>
  </div>
</section>

<section class="section section-white">
  <div class="container">
    <div class="filter-bar" id="project-filters">
      {filter_buttons}
    </div>
    <div class="project-grid" id="project-grid">
      {project_cards_html}
    </div>
  </div>
</section>

{final_cta()}
"""

write("projects.html", page(
    title="Projects | Legacy Builds Group",
    description="Browse residential, commercial, and industrial design-build projects completed and in progress across Metro Detroit.",
    canonical="/projects.html",
    active="projects",
    body=projects_body,
))

# ===========================================================================
# INDIVIDUAL PROJECT PAGE (template, populated with one example) — Section 22
# ===========================================================================

gallery_items = "\n      ".join('<div class="gallery-item" aria-hidden="true"></div>' for _ in range(6))

project_detail_body = f"""<section class="project-hero">
  <div class="container project-hero-inner">
    <span class="tag" style="color:var(--gold);">Residential &middot; Bloomfield Hills, MI</span>
    <h1>Custom Luxury Home</h1>
    <div class="project-hero-meta">
      <span><strong>City:</strong> Bloomfield Hills, MI</span>
      <span><strong>Category:</strong> Residential</span>
      <span><strong>Completed:</strong> 2025</span>
    </div>
  </div>
</section>

<section class="section section-white">
  <div class="container">
    {breadcrumb(("Home", "/"), ("Projects", "/projects.html"), ("Custom Luxury Home", None))}
    <div class="project-body-grid">
      <div class="project-summary">
        <h2>Project Goal</h2>
        <p>Deliver a complete custom home on a vacant lot &mdash; from architectural concept through construction and move-in &mdash; without the client needing to manage separate architecture, engineering, and construction firms.</p>

        <h2>Existing Condition</h2>
        <p>A vacant, wooded parcel with no existing structures, requiring full site planning, utility coordination, and municipal approval from the ground up.</p>

        <h2>Challenges</h2>
        <p>Sloped topography and municipal setback requirements shaped the buildable footprint, while the client&rsquo;s timeline required design, engineering, and permitting to move in parallel rather than in sequence.</p>

        <h2>Scope</h2>
        <p>Architectural design, structural and MEP engineering, permitting, and full construction of a single-family custom residence, including site work and landscaping coordination.</p>

        <h2>Design Solution</h2>
        <p>An architectural plan that worked with the site&rsquo;s natural grade rather than against it, reducing excavation cost while preserving mature trees along the property line.</p>

        <h2>Construction Solution</h2>
        <p>A sequenced construction schedule that coordinated foundation, framing, and MEP rough-in with municipal inspections to avoid delays, with weekly progress updates to the client throughout.</p>

        <h2>Final Outcome</h2>
        <p>A completed custom home delivered on budget, with the client&rsquo;s architecture, engineering, and construction handled by a single accountable team from concept through occupancy.</p>
      </div>

      <aside class="project-facts">
        <dl>
          <dt>Location</dt><dd>Bloomfield Hills, MI</dd>
          <dt>Type</dt><dd>Residential &mdash; New Construction</dd>
          <dt>Square Footage</dt><dd>4,850 sq ft</dd>
          <dt>Services</dt><dd>Architecture, Engineering, MEP, Construction</dd>
          <dt>Timeline</dt><dd>11 Months</dd>
          <dt>Status</dt><dd>Completed</dd>
          <dt>Municipality</dt><dd>City of Bloomfield Hills</dd>
        </dl>
      </aside>
    </div>

    <div class="project-gallery">
      {gallery_items}
    </div>

    <div class="article-cta" style="margin-top:64px;">
      <h3>Planning a similar project?</h3>
      <a href="/contact.html" class="btn btn-gold">Start Your Project</a>
    </div>
  </div>
</section>
"""

write("projects/custom-luxury-home.html", page(
    title="Custom Luxury Home, Bloomfield Hills MI | Legacy Builds Group",
    description="A complete residential design-build project in Bloomfield Hills, MI, from architectural concept through construction and move-in.",
    canonical="/projects/custom-luxury-home.html",
    active="projects",
    body=project_detail_body,
))

# ===========================================================================
# INSIGHTS INDEX  (insights.html) — Section 23
# ===========================================================================

ARTICLES = [
    ("What Is a Design-Build Contractor?", "Construction Planning", "A plain-language look at the design-build delivery model and how it differs from hiring separate firms.", "/insights/what-is-a-design-build-contractor.html"),
    ("The Difference Between Design-Build and Design-Bid-Build", "Construction Planning", "How the two most common project delivery methods compare on cost, schedule, and accountability.", None),
    ("What to Expect During the Permitting Process", "Permitting", "A walkthrough of municipal review, common delays, and how to keep a project moving.", None),
    ("How Long Does a Custom Home Take to Build?", "Residential Development", "Realistic timeline expectations from design through move-in for a custom home.", None),
    ("Why MEP Coordination Matters", "MEP", "How early mechanical, electrical, and plumbing coordination prevents costly conflicts later.", None),
    ("Common Causes of Construction Delays", "Project Management", "The most frequent sources of schedule slippage &mdash; and how a design-build team reduces them.", None),
    ("What Should Be Included in a Construction Proposal?", "Project Management", "The scope, pricing, and schedule details a thorough proposal should always cover.", None),
    ("How to Prepare for a Commercial Renovation", "Commercial Construction", "What business owners should plan for before starting a commercial build-out.", None),
    ("Understanding Construction Allowances", "Project Management", "How allowances work in a construction budget and where they most often cause confusion.", None),
    ("How Change Orders Work", "Project Management", "What triggers a change order, how it&rsquo;s priced, and how to keep it from derailing a schedule."),
]
# fix: last tuple missing href field
ARTICLES[-1] = ("How Change Orders Work", "Project Management", "What triggers a change order, how it&rsquo;s priced, and how to keep it from derailing a schedule.", None)

CATEGORIES = ["All", "Construction Planning", "Permitting", "Architecture", "Engineering", "MEP", "Residential Development", "Commercial Construction", "Project Management"]

def insight_card(title, cat, excerpt, href):
    inner = f"""<div class="insight-media" aria-hidden="true"></div>
        <div class="insight-body">
          <span class="tag">{cat}</span>
          <h3>{title}</h3>
          <p>{excerpt}</p>"""
    if href:
        inner += f'\n          <a href="{href}" class="link-gold">Read Article <span aria-hidden="true">&rarr;</span></a>'
        return f'<article class="insight-card reveal" data-category="{cat.lower().replace(" ", "-")}">{inner}\n        </div></article>'
    inner += '\n          <span class="status-pill">Coming Soon</span>'
    return f'<article class="insight-card disabled reveal" data-category="{cat.lower().replace(" ", "-")}">{inner}\n        </div></article>'

insight_filter_buttons = "\n      ".join(
    f'<button class="filter-btn{" active" if c == "All" else ""}" data-filter="{c.lower().replace(" ", "-")}">{c}</button>'
    for c in CATEGORIES
)
insight_cards_html = "\n      ".join(insight_card(*a) for a in ARTICLES)

insights_body = f"""<section class="page-hero">
  <div class="container">
    {breadcrumb(("Home", "/"), ("Insights", None))}
    <h1>Insights</h1>
    <p class="page-hero-sub">Practical guidance on design-build construction, permitting, and project planning in Metro Detroit.</p>
  </div>
</section>

<section class="section section-white">
  <div class="container">
    <div class="filter-bar" id="insight-filters">
      {insight_filter_buttons}
    </div>
    <div class="insight-full-grid" id="insight-grid">
      {insight_cards_html}
    </div>
  </div>
</section>

{final_cta()}
"""

write("insights.html", page(
    title="Insights | Legacy Builds Group",
    description="Practical articles on design-build construction, permitting, project planning, and MEP coordination from Legacy Builds Group.",
    canonical="/insights.html",
    active="insights",
    body=insights_body,
))

# ===========================================================================
# SAMPLE ARTICLE — Section 23
# ===========================================================================

article_body = """<section class="page-hero">
  <div class="container">
    <p class="breadcrumb"><a href="/">Home</a> <span aria-hidden="true">/</span> <a href="/insights.html">Insights</a> <span aria-hidden="true">/</span> <span>What Is a Design-Build Contractor?</span></p>
    <h1>What Is a Design-Build Contractor?</h1>
  </div>
</section>

<section class="section section-white">
  <div class="container">
    <div class="article-body">
      <div class="article-meta">
        <span class="tag">Construction Planning</span>
        <span>&middot;</span>
        <span>5 min read</span>
      </div>

      <p>If you&rsquo;ve started researching how to build or renovate a property, you&rsquo;ve likely come across the term &ldquo;design-build.&rdquo; It describes a project delivery method &mdash; and understanding it is one of the most useful things you can do before choosing how to staff your project.</p>

      <h2>The Traditional Model: Design-Bid-Build</h2>
      <p>In the traditional approach, an owner hires an architect to design the project, then separately bids the completed design out to contractors. The architect and contractor typically have no formal relationship, which means the owner sits in the middle &mdash; managing communication, resolving conflicts between design intent and construction reality, and absorbing the risk when the two sides disagree.</p>

      <h2>The Design-Build Model</h2>
      <p>A design-build contractor brings architecture, engineering, and construction under one contract and one accountable team. Instead of a design being finished and then handed off, design and construction knowledge inform each other throughout the process.</p>
      <ul>
        <li>One point of contact and one contract for the entire project</li>
        <li>Design decisions evaluated against real construction cost and constructability</li>
        <li>Engineering and permitting coordinated alongside design, not after it</li>
        <li>Fewer handoffs, which typically means fewer conflicts and delays</li>
      </ul>

      <h2>When Design-Build Makes Sense</h2>
      <p>Design-build tends to work well for owners who want a single accountable team, a more predictable schedule, and a budget that&rsquo;s informed by construction realities from the earliest design conversations &mdash; which is why it&rsquo;s the model Legacy Builds Group is built around.</p>

      <div class="article-cta">
        <h3>Have a project in mind?</h3>
        <a href="/contact.html" class="btn btn-gold">Start Your Project</a>
      </div>
    </div>
  </div>
</section>
"""

write("insights/what-is-a-design-build-contractor.html", page(
    title="What Is a Design-Build Contractor? | Legacy Builds Group",
    description="A plain-language explanation of the design-build delivery model and how it compares to hiring separate architecture and construction firms.",
    canonical="/insights/what-is-a-design-build-contractor.html",
    active="insights",
    body=article_body,
))

# ===========================================================================
# CONTACT  (contact.html) — Section 14
# ===========================================================================

contact_body = f"""<section class="page-hero">
  <div class="container">
    {breadcrumb(("Home", "/"), ("Contact", None))}
    <h1>Let&rsquo;s Talk About Your Project</h1>
    <p class="page-hero-sub">Tell us what you are planning. Our team will review the project details and contact you to discuss scope, site conditions, timing, budget expectations, and next steps.</p>
  </div>
</section>

<section class="section section-cta">
  <div class="container contact-grid">
    <div class="contact-copy reveal">
      <h2>Start a Conversation</h2>
      <p class="lead">Reach out directly, or send a project inquiry and our team will respond within one business day.</p>

      <ul class="contact-info">
        <li><span class="contact-icon">{ICON_PHONE}</span><span>(313) 555-LEGACY</span></li>
        <li><span class="contact-icon">{ICON_MAIL}</span><span>info@legacybuildsgroup.com</span></li>
        <li><span class="contact-icon">{ICON_PIN}</span><span>Metro Detroit, Michigan</span></li>
        <li><span class="contact-icon">{ICON_CLOCK}</span><span>Mon&ndash;Fri, 8:00 AM&ndash;5:00 PM</span></li>
      </ul>

      <div class="contact-social">
        <a href="#" aria-label="Facebook">{ICON_FB}</a>
        <a href="#" aria-label="Instagram">{ICON_IG}</a>
        <a href="#" aria-label="LinkedIn">{ICON_LI}</a>
      </div>

      <div class="contact-map" aria-hidden="true"><span>Metro Detroit, MI &mdash; Service Area Map</span></div>
    </div>

    <form class="contact-form reveal" id="contact-form">
      <div class="form-row">
        <div>
          <label class="form-label" for="f-name">Full Name</label>
          <input type="text" id="f-name" name="name" placeholder="Jane Smith" required>
        </div>
        <div>
          <label class="form-label" for="f-email">Email</label>
          <input type="email" id="f-email" name="email" placeholder="jane@email.com" required>
        </div>
      </div>
      <div class="form-row">
        <div>
          <label class="form-label" for="f-phone">Phone</label>
          <input type="tel" id="f-phone" name="phone" placeholder="(313) 555-0100">
        </div>
        <div>
          <label class="form-label" for="f-address">Project Address</label>
          <input type="text" id="f-address" name="address" placeholder="City, MI">
        </div>
      </div>
      <div class="form-row">
        <div>
          <label class="form-label" for="f-type">Project Type</label>
          <select id="f-type" name="project_type">
            <option value="">Select one</option>
            <option>Residential &mdash; New Construction</option>
            <option>Residential &mdash; Renovation / Addition</option>
            <option>Commercial</option>
            <option>Industrial</option>
            <option>Other</option>
          </select>
        </div>
        <div>
          <label class="form-label" for="f-budget">Estimated Budget</label>
          <select id="f-budget" name="budget">
            <option value="">Select a range</option>
            <option>Under $150,000</option>
            <option>$150,000 &ndash; $500,000</option>
            <option>$500,000 &ndash; $1,000,000</option>
            <option>$1,000,000+</option>
            <option>Not sure yet</option>
          </select>
        </div>
      </div>
      <div>
        <label class="form-label" for="f-timeline">Desired Timeline</label>
        <select id="f-timeline" name="timeline">
          <option value="">Select a timeframe</option>
          <option>As soon as possible</option>
          <option>1&ndash;3 months</option>
          <option>3&ndash;6 months</option>
          <option>6+ months</option>
        </select>
      </div>
      <div>
        <label class="form-label" for="f-details">Project Description</label>
        <textarea id="f-details" name="details" rows="4" placeholder="Tell us about your goals, site, and scope."></textarea>
      </div>
      <div>
        <label class="form-label" for="f-upload">File Upload <span style="font-weight:400;color:rgba(245,243,239,0.45);">(plans, photos, or documents &mdash; optional)</span></label>
        <input type="file" id="f-upload" name="upload">
      </div>
      <div>
        <span class="form-label">Preferred Contact Method</span>
        <div class="radio-row">
          <label><input type="radio" name="contact_method" value="email" checked> Email</label>
          <label><input type="radio" name="contact_method" value="phone"> Phone</label>
          <label><input type="radio" name="contact_method" value="text"> Text</label>
        </div>
      </div>
      <button type="submit" class="btn btn-gold btn-block">Submit Project Inquiry</button>
      <p class="form-note" id="form-note" role="status"></p>
      <p class="form-fineprint">This form is front-end only in this build. Connect it to your CRM, email service, or form backend (with spam protection) before launch.</p>
    </form>
  </div>
</section>
"""

write("contact.html", page(
    title="Contact | Legacy Builds Group",
    description="Start a project with Legacy Builds Group. Call, email, or submit a project inquiry and our Metro Detroit team will respond within one business day.",
    canonical="/contact.html",
    active="contact",
    body=contact_body,
))

# ===========================================================================
# 404
# ===========================================================================

error_body = """<section class="section error-page">
  <div class="container" style="text-align:center;">
    <h1>404</h1>
    <p style="color:var(--gray-600);font-size:1.1rem;margin-top:12px;">We couldn&rsquo;t find the page you were looking for.</p>
    <a href="/" class="btn btn-gold" style="margin-top:32px;">Back to Home</a>
  </div>
</section>
"""

write("404.html", page(
    title="Page Not Found | Legacy Builds Group",
    description="The page you're looking for could not be found.",
    canonical="/404.html",
    active="",
    body=error_body,
))

# ===========================================================================
# LEGAL STUBS
# ===========================================================================

def legal_page(slug, title):
    body = f"""<section class="page-hero">
  <div class="container">
    {breadcrumb(("Home", "/"), (title, None))}
    <h1>{title}</h1>
  </div>
</section>
<section class="section section-white">
  <div class="container-narrow">
    <p style="color:var(--gray-600);font-size:1rem;">This is placeholder legal content prepared for design and development purposes only. Replace this page with {title.lower()} language reviewed by your attorney before launch.</p>
    <p style="color:var(--gray-600);font-size:0.9rem;margin-top:16px;">Last updated: [Date]</p>
  </div>
</section>
"""
    write(f"{slug}.html", page(
        title=f"{title} | Legacy Builds Group",
        description=f"{title} for the Legacy Builds Group website.",
        canonical=f"/{slug}.html",
        active="",
        body=body,
    ))

legal_page("privacy", "Privacy Policy")
legal_page("terms", "Terms of Service")
legal_page("accessibility", "Accessibility Statement")

print("\\nAll pages generated.")
